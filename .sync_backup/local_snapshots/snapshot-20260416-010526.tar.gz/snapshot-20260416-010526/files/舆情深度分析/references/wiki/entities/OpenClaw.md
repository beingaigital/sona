---
title: OpenClaw
updated_at: 2026-04-15 19:12:49
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [74_【课前十分钟】AI“龙虾”来了，我们该如何从容“烹饪”？.md](sources/74__课前十分钟_AI_龙虾_来了_我们该如何从容_烹饪.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/74_【课前十分钟】AI“龙虾”来了，我们该如何从容“烹饪”？.md

## 近期增量
- --- title: 【课前十分钟】AI“龙虾”来了，我们该如何从容“烹饪”？ source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/74_【课前十分钟】AI“龙虾”来了，我们该如何从容“烹饪”？.md updated_

## 关联概念
- [人工智能](../concepts/人工智能.md)、[职场变革](../concepts/职场变革.md)、[技术伦理](../concepts/技术伦理.md)、[开放教育学院](../concepts/开放教育学院.md)

## 关联实体
- [开放教育学院](../entities/开放教育学院.md)、[浙江宣传](../entities/浙江宣传.md)、[人工智能](../entities/人工智能.md)、[职场变革](../entities/职场变革.md)、[技术伦理](../entities/技术伦理.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
