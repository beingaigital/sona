---
title: +
updated_at: 2026-04-15 18:21:03
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [29_浙江宣传篇篇10万+，到底为什么？那是“始终相信文字的力量”.md](sources/29_浙江宣传篇篇10万_到底为什么_那是_始终相信文字的力量.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/29_浙江宣传篇篇10万+，到底为什么？那是“始终相信文字的力量”.md

## 近期增量
- --- title: 浙江宣传篇篇 10 万 + 现象分析 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/29_浙江宣传篇篇 10 万 +，到底为什么？那是“始终相信文字的力量”.md updated_at: 2

## 关联概念
- [政务传播](../concepts/政务传播.md)、[新媒体运营](../concepts/新媒体运营.md)、[传播效果](../concepts/传播效果.md)

## 关联实体
- [浙江宣传](../entities/浙江宣传.md)、[南村子文集](../entities/南村子文集.md)、[惊之鸿](../entities/惊之鸿.md)、[政务新媒体](../entities/政务新媒体.md)、[10](../entities/10.md)、[万](../entities/万.md)、[文字力量](../entities/文字力量.md)、[新媒体运营](../entities/新媒体运营.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
