---
title: NBA
updated_at: 2026-04-15 19:09:25
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [71_从“跪族篮孩”到“粉底液将军”：饭圈文化的十年漂流，与一场未完成的成人礼.md](sources/71_从_跪族篮孩_到_粉底液将军_饭圈文化的十年漂流_与一场未完成的成人礼.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/71_从“跪族篮孩”到“粉底液将军”：饭圈文化的十年漂流，与一场未完成的成人礼.md

## 近期增量
- --- title: 从“跪族篮孩”到“粉底液将军”：饭圈文化的十年漂流，与一场未完成的成人礼 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/71_从“跪族篮孩”到“粉底液将军”：饭圈文化的十年漂流，与一场未完成

## 关联概念
- [公共秩序](../concepts/公共秩序.md)、[未成年人](../concepts/未成年人.md)、[平台治理](../concepts/平台治理.md)、[文化安全](../concepts/文化安全.md)、[审美导向](../concepts/审美导向.md)

## 关联实体
- [阳树上](../entities/阳树上.md)、[刘海龙](../entities/刘海龙.md)、[郭小安](../entities/郭小安.md)、[杨绍婷](../entities/杨绍婷.md)、[潘妮妮](../entities/潘妮妮.md)、[钧正平](../entities/钧正平.md)、[张凌赫](../entities/张凌赫.md)、[蔡徐坤](../entities/蔡徐坤.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
