---
title: 小 p
updated_at: 2026-04-15 18:22:35
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [30_行测大拿省考杭州某区面试89+的面试碎碎念.md](sources/30_行测大拿省考杭州某区面试89_的面试碎碎念.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/30_行测大拿省考杭州某区面试89+的面试碎碎念.md

## 近期增量
- --- title: 省考面试高分经验与备考方法论 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/30_行测大拿省考杭州某区面试 89+ 的面试碎碎念.md updated_at: 2024-05-20 10:0

## 关联概念
- [公共就业](../concepts/公共就业.md)、[考试培训](../concepts/考试培训.md)、[个人发展](../concepts/个人发展.md)、[Tessy 带你上岸](../concepts/Tessy_带你上岸.md)

## 关联实体
- [慎独](../entities/慎独.md)、[Tessy 带你上岸](../entities/Tessy_带你上岸.md)、[浙江省考](../entities/浙江省考.md)、[杭州市直](../entities/杭州市直.md)、[之江轩](../entities/之江轩.md)、[粉笔](../entities/粉笔.md)、[花生](../entities/花生.md)、[超格](../entities/超格.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
