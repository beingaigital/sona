---
title: OPPO
updated_at: 2026-04-15 18:53:28
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [57_教育部：义务教育学校禁设重点班！小米调价？微信：张雪机车在小程序卖爆了，2 周狂卖超万台.md](sources/57_教育部_义务教育学校禁设重点班_小米调价_微信_张雪机车在小程序卖爆了_2_周狂卖超万台.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/57_教育部：义务教育学校禁设重点班！小米调价？微信：张雪机车在小程序卖爆了，2 周狂卖超万台.md

## 近期增量
- --- title: 舆情日报编译：2026-04-03 教育政策与科技热点 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/57_教育部：义务教育学校禁设重点班！小米调价？微信：张雪机车在小程序卖爆了，2 周狂卖

## 关联概念
- [公共秩序](../concepts/公共秩序.md)、[平台治理](../concepts/平台治理.md)、[消费者权益](../concepts/消费者权益.md)、[国际关系](../concepts/国际关系.md)

## 关联实体
- [教育部](../entities/教育部.md)、[小米](../entities/小米.md)、[微信](../entities/微信.md)、[张雪](../entities/张雪.md)、[老爸评测](../entities/老爸评测.md)、[比亚迪](../entities/比亚迪.md)、[小鹏汽车](../entities/小鹏汽车.md)、[苹果](../entities/苹果.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
