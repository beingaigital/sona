---
title: VC 机构
updated_at: 2026-04-15 18:16:23
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [24_张雪夺冠，资本疯抢：那个从修理铺走出的男人，打了谁的脸？.md](sources/24_张雪夺冠_资本疯抢_那个从修理铺走出的男人_打了谁的脸.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/24_张雪夺冠，资本疯抢：那个从修理铺走出的男人，打了谁的脸？.md

## 近期增量
- --- title: 张雪夺冠与资本舆情分析 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/24_张雪夺冠，资本疯抢：那个从修理铺走出的男人，打了谁的脸？.md updated_at: 2026-04-02 16

## 关联概念
- [创业环境](../concepts/创业环境.md)、[资本舆论](../concepts/资本舆论.md)、[公共安全](../concepts/公共安全.md)、[制造业升级](../concepts/制造业升级.md)、[嫣然天使基金](../concepts/嫣然天使基金.md)、[公安部交通管理局](../concepts/公安部交通管理局.md)

## 关联实体
- [张雪](../entities/张雪.md)、[张雪机车](../entities/张雪机车.md)、[凯越机车](../entities/凯越机车.md)、[陈光标](../entities/陈光标.md)、[嫣然天使基金](../entities/嫣然天使基金.md)、[公安部交通管理局](../entities/公安部交通管理局.md)、[重庆市政府](../entities/重庆市政府.md)、[创业环境](../entities/创业环境.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
