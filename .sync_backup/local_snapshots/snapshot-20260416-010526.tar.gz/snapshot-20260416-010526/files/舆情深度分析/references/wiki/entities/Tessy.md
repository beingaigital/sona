---
title: Tessy
updated_at: 2026-04-16 00:25:41
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [30_行测大拿省考杭州某区面试89+的面试碎碎念.md](sources/30_行测大拿省考杭州某区面试89_的面试碎碎念.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/30_行测大拿省考杭州某区面试89+的面试碎碎念.md

## 近期增量
- --- title: 30_行测大拿省考杭州某区面试 89+ 的面试碎碎念 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/30_行测大拿省考杭州某区面试 89+ 的面试碎碎念.md updated_at: 202

## 关联概念
- [公共部门招聘](../concepts/公共部门招聘.md)、[面试技巧](../concepts/面试技巧.md)、[个人成长](../concepts/个人成长.md)、[教育培训](../concepts/教育培训.md)

## 关联实体
- [慎独](../entities/慎独.md)、[杭州市某区](../entities/杭州市某区.md)、[浙江省考](../entities/浙江省考.md)、[之江轩](../entities/之江轩.md)、[面试技巧](../entities/面试技巧.md)、[个人成长](../entities/个人成长.md)、[教育培训](../entities/教育培训.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
