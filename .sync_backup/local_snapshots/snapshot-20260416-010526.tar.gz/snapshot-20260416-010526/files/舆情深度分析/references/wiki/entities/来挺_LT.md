---
title: 来挺 LT
updated_at: 2026-04-15 18:44:55
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [48_26届上外新传经验贴2专硕  东北双非小妹专业课也能考271分.md](sources/48_26届上外新传经验贴2专硕_东北双非小妹专业课也能考271分.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/48_26届上外新传经验贴2专硕  东北双非小妹专业课也能考271分.md

## 近期增量
- --- title: 26 届上外新传专硕备考经验与心态分析 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/48_26 届上外新传经验贴 2 专硕 东北双非小妹专业课也能考 271 分.md updated_at

## 关联概念
- [高等教育](../concepts/高等教育.md)、[职业培训](../concepts/职业培训.md)、[心理健康](../concepts/心理健康.md)、[信息行为](../concepts/信息行为.md)、[上海外国语大学](../concepts/上海外国语大学.md)

## 关联实体
- [上海外国语大学](../entities/上海外国语大学.md)、[微信](../entities/微信.md)、[哔哩哔哩](../entities/哔哩哔哩.md)、[肖秀荣](../entities/肖秀荣.md)、[墨墨背单词](../entities/墨墨背单词.md)、[高等教育](../entities/高等教育.md)、[职业培训](../entities/职业培训.md)、[心理健康](../entities/心理健康.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
