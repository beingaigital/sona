---
title: KOL
updated_at: 2026-04-15 19:29:00
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [舆情分析方法论.md](sources/output_舆情分析方法论.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/wiki/output/舆情分析方法论.md

## 近期增量
- --- title: 舆情分析方法论 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/wiki/output/舆情分析方法论.md updated_at: 2024-05-22 15:30:00 tags: - 舆情分析 

## 关联概念
- [公共秩序](../concepts/公共秩序.md)、[平台治理](../concepts/平台治理.md)、[危机公关](../concepts/危机公关.md)、[社会心理](../concepts/社会心理.md)

## 关联实体
- [政府](../entities/政府.md)、[网民](../entities/网民.md)、[媒体](../entities/媒体.md)、[平台](../entities/平台.md)、[厦门市政府](../entities/厦门市政府.md)、[公共秩序](../entities/公共秩序.md)、[危机公关](../entities/危机公关.md)、[社会心理](../entities/社会心理.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
