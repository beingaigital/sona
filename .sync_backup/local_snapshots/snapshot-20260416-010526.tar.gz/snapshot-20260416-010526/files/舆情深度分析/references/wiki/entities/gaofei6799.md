---
title: gaofei6799
updated_at: 2026-04-15 18:29:16
wiki_section: entities
source_type: mixed
confidence: medium
tags: [自动生成, 增量更新]
---

## 定义
证据不足

## 关联来源
- [35_如何把1000篇的浙江特色素材变成你自己的？让申论面试游刃有余.md](sources/35_如何把1000篇的浙江特色素材变成你自己的_让申论面试游刃有余.md) | /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/35_如何把1000篇的浙江特色素材变成你自己的？让申论面试游刃有余.md

## 近期增量
- --- title: 如何把 1000 篇的浙江特色素材变成你自己的？让申论面试游刃有余 source_file: /Users/biaowenhuang/Documents/sona-master/舆情深度分析/references/raw/35_如何把 1000 篇的浙江特色素材变成你自己的？让申论面试游刃有余.m

## 关联概念
- [公共政策传播](../concepts/公共政策传播.md)、[公务员能力建设](../concepts/公务员能力建设.md)、[政务叙事](../concepts/政务叙事.md)、[胖胖猫浙江上岸笔记](../concepts/胖胖猫浙江上岸笔记.md)

## 关联实体
- [胖胖猫浙江上岸笔记](../entities/胖胖猫浙江上岸笔记.md)、[浙江宣传](../entities/浙江宣传.md)

## 待补充
- 可补充关键事实、机制解释与风险建议。
